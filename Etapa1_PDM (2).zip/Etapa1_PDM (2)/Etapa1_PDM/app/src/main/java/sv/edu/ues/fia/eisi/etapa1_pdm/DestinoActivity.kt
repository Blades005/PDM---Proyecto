package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class DestinoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_destino)

        val btnVerMas = findViewById<Button>(R.id.btn_see_more)

        btnVerMas.setOnClickListener {
            val intent = Intent(this, ReservarAhoraActivity::class.java)
            startActivity(intent)
        }
    }
}
