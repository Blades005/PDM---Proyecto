package sv.edu.ues.fia.eisi.etapa1_pdm

import android.os.Bundle
import android.widget.Switch
import android.content.SharedPreferences
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class AdministrarNotificacionesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_administrar_notificaciones)

        // 🔹 Instancia de SharedPreferences para guardar la configuración
        val sharedPreferences = getSharedPreferences("NotificacionesPrefs", MODE_PRIVATE)

        // 🔹 Vincular los Switch con su ID
        val switchTravelUpdates = findViewById<Switch>(R.id.switch_travel_updates)
        val switchMessages = findViewById<Switch>(R.id.switch_messages)
        val switchPromotions = findViewById<Switch>(R.id.switch_promotions)

        // 🔹 Cargar configuración guardada
        switchTravelUpdates.isChecked = sharedPreferences.getBoolean("travelUpdates", false)
        switchMessages.isChecked = sharedPreferences.getBoolean("messages", false)
        switchPromotions.isChecked = sharedPreferences.getBoolean("promotions", false)

        // 🔹 Guardar cambios cuando el usuario activa/desactiva los Switch
        switchTravelUpdates.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("travelUpdates", isChecked).apply()
        }

        switchMessages.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("messages", isChecked).apply()
        }

        switchPromotions.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("promotions", isChecked).apply()
        }
    }
}