package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ReservarAhoraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reservar_ahora)

        val btnReservar = findViewById<Button>(R.id.btn_reserve_now)

        btnReservar.setOnClickListener {
            val intent = Intent(this, ConfirmarReservaActivity::class.java)
            startActivity(intent)
        }
    }
}


