package sv.edu.ues.fia.eisi.etapa1_pdm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegistroUsuarioActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario)

        dbHelper = DatabaseHelper(this)

        val etNombre = findViewById<EditText>(R.id.et_nombre)
        val etCorreo = findViewById<EditText>(R.id.et_correo)
        val etTelefono = findViewById<EditText>(R.id.et_telefono)
        val etPais = findViewById<EditText>(R.id.et_pais)
        val etBiografia = findViewById<EditText>(R.id.et_biografia)
        val etContrasena = findViewById<EditText>(R.id.et_contrasena) // 🔹 Agregado
        val btnRegistrar = findViewById<Button>(R.id.btn_registrar)

        btnRegistrar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val correo = etCorreo.text.toString()
            val telefono = etTelefono.text.toString()
            val pais = etPais.text.toString()
            val biografia = etBiografia.text.toString()
            val contrasena = etContrasena.text.toString() // 🔹 Capturamos la contraseña

            if (nombre.isEmpty() || correo.isEmpty() || telefono.isEmpty() || pais.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val resultado = dbHelper.registrarUsuario(nombre, correo, telefono, pais, biografia, contrasena)

            if (resultado > 0) {
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
