package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class ConfirmarReservaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_confirmar_reserva)

        val confirmarBtn = findViewById<Button>(R.id.button)

        confirmarBtn.setOnClickListener {
            val intent = Intent(this, ReservaConfirmadaActivity::class.java)
            startActivity(intent)
        }
    }
}
