package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "ViajesDB", null, 2)
{
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
        CREATE TABLE usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            correo TEXT UNIQUE NOT NULL,
            telefono TEXT UNIQUE NOT NULL,
            pais TEXT NOT NULL,
            biografia TEXT,
            contrasena TEXT NOT NULL
        )
    """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS usuarios")
        onCreate(db) //
    }

    // 🔹 Método para registrar usuario en SQLite
    fun registrarUsuario(nombre: String, correo: String, telefono: String, pais: String, biografia: String, contrasena: String): Long {
        val db = writableDatabase
        val valores = ContentValues().apply {
            put("nombre", nombre)
            put("correo", correo)
            put("telefono", telefono)
            put("pais", pais)
            put("biografia", biografia)
            put("contrasena", contrasena) // 🔹 Agregamos la contraseña
        }

        val resultado = db.insert("usuarios", null, valores)

        if (resultado == -1L) {
            android.util.Log.e("DatabaseHelper", "Error al registrar usuario en SQLite")
        }

        return resultado
    }

    // 🔹 Método para verificar si el teléfono está registrado
    fun usuarioPorTelefono(telefono: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM usuarios WHERE telefono = ?", arrayOf(telefono))
        val existe = cursor.count > 0
        cursor.close()
        return existe
    }

    // 🔹 Método para verificar si el correo está registrado
    fun usuarioPorCorreo(correo: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM usuarios WHERE correo = ?", arrayOf(correo))
        val existe = cursor.count > 0
        cursor.close()
        return existe
    }
    // 🔹 Método para validar usuario en SQLite
    fun validarUsuario(correo: String, contrasena: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM usuarios WHERE correo = ? AND contrasena = ?", arrayOf(correo, contrasena))
        val existe = cursor.count > 0
        cursor.close()
        return existe
    }
}