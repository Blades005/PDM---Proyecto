package sv.edu.ues.fia.eisi.etapa1_pdm

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class PlanificaViajeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_planifica_viaje)

        val etDates = findViewById<EditText>(R.id.et_dates)
        val btnBuscar = findViewById<Button>(R.id.btn_search)

        // Abrir selector de fecha
        etDates.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePicker = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                etDates.setText(selectedDate)
            }, year, month, day)

            datePicker.show()
        }

        // Botón Buscar -> ir a pantalla Destino
        btnBuscar.setOnClickListener {
            val intent = Intent(this, DestinoActivity::class.java)
            startActivity(intent)
        }
    }
}
