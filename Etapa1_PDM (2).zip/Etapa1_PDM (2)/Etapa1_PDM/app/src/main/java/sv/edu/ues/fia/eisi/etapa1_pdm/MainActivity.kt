package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        val etPhone = findViewById<EditText>(R.id.et_phone)
        val btnContinue = findViewById<Button>(R.id.btn_continue)
        val btnContinueEmail = findViewById<Button>(R.id.btn_continue_email)
        val btnRegister = findViewById<Button>(R.id.btn_register) // 🔹 Agregado

        // 🔹 Manejo de login con teléfono
        btnContinue.setOnClickListener {
            val telefono = etPhone.text.toString()

            if (telefono.isEmpty()) {
                Toast.makeText(this, "Ingrese un número de teléfono", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (dbHelper.usuarioPorTelefono(telefono)) {
                Toast.makeText(this, "Iniciando sesión...", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, LobbyActivity::class.java))
            } else {
                Toast.makeText(this, "Teléfono no registrado, redirigiendo al registro", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, RegistroUsuarioActivity::class.java)
                intent.putExtra("telefono", telefono)
                startActivity(intent)
            }
        }

        // 🔹 Ir a pantalla de login con correo
        btnContinueEmail.setOnClickListener {
            startActivity(Intent(this, LoginCorreoActivity::class.java))
        }

        // 🔹 Ir a pantalla de registro
        btnRegister.setOnClickListener {
            startActivity(Intent(this, RegistroUsuarioActivity::class.java))
        }
    }
}
