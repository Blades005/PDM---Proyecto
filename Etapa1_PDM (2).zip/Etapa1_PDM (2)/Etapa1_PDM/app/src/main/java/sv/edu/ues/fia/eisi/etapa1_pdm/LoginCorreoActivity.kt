package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginCorreoActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_correo)

        dbHelper = DatabaseHelper(this)

        val etCorreo = findViewById<EditText>(R.id.et_email)
        val etContrasena = findViewById<EditText>(R.id.et_password) // 🔹 Agregado
        val btnLogin = findViewById<Button>(R.id.btn_login)

        btnLogin.setOnClickListener {
            val correo = etCorreo.text.toString()
            val contrasena = etContrasena.text.toString() // 🔹 Captura la contraseña

            if (correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Ingrese su correo y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (dbHelper.validarUsuario(correo, contrasena)) {
                Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, LobbyActivity::class.java))
            } else {
                Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}