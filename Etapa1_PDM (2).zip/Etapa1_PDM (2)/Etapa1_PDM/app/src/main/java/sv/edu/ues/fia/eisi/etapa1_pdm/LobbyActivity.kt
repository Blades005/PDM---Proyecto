package sv.edu.ues.fia.eisi.etapa1_pdm

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class LobbyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby)

        // Clic en el botón Explora
        val btnExplora = findViewById<LinearLayout>(R.id.btnExplora)
        btnExplora.setOnClickListener {
            val intent = Intent(this, PlanificaViajeActivity::class.java)
            startActivity(intent)
        }
    }
}
